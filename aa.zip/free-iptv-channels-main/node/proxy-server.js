const http = require('http');
const https = require('https');
const url = require('url');
const zlib = require('zlib');

const hostname = '0.0.0.0';
const port = 4242;
const VPS_HOST = process.env.VPS_HOST || 'localhost:4242'; // Set this to your VPS hostname or IP

const regionNameMap = {
    ar: "Argentina",
    br: "Brazil",
    ca: "Canada",
    cl: "Chile",
    de: "Germany",
    dk: "Denmark",
    es: "Spain",
    fr: "France",
    gb: "United Kingdom",
    it: "Italy",
    mx: "Mexico",
    no: "Norway",
    se: "Sweden",
    us: "United States"
};

const server = http.createServer(async (req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const params = parsedUrl.query;
    const pathname = parsedUrl.pathname;
    const region = (params.region || 'us').toLowerCase().trim();
    const service = params.service;
    const sort = params.sort || 'name';

    // Handle proxy streaming requests
    if (pathname.startsWith('/proxy/')) {
        return handleProxyStream(req, res, pathname);
    }

    // Check for the root path "/"
    if (pathname === '/' && !parsedUrl.query.service) {
        return handleHomePage(res);
    }

    // Check if the service parameter is missing
    if (!service) {
        res.writeHead(400, {
            'Content-Type': 'text/plain'
        });
        return res.end('Error: No service type provided');
    }

    // Handle Pluto TV service
    if (service.toLowerCase() === 'plutotv' || service.toLowerCase() === 'pluto') {
        const plutoOutput = await handlePlutoTV(region, sort);
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        return res.end(plutoOutput);
    }

    // Handle Plex service
    if (service.toLowerCase() === 'plex') {
        const plexOutput = await handlePlex(region, sort);
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        return res.end(plexOutput);
    }

    // Handle SamsungTVPlus service
    if (service.toLowerCase() === 'samsungtvplus' || service.toLowerCase() === 'samsung') {
        const samsungOutput = await handleSamsungTVPlus(region, sort);
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        return res.end(samsungOutput);
    }

    // Handle Roku service
    if (service.toLowerCase() === 'roku') {
        const rokuOutput = await handleRoku(sort);
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        return res.end(rokuOutput);
    }

    // Handle Stirr service
    if (service.toLowerCase() === 'stirr') {
        const stirrOutput = await handleStirr(sort);
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        return res.end(stirrOutput);
    }

    // Handle Tubi service
    if (service.toLowerCase() === 'tubi') {
        const tubiOutput = await handleTubi();
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        return res.end(tubiOutput);
    }

    // Handle PBS service
    if (service.toLowerCase() === 'pbs') {
        const pbsOutput = await handlePBS();
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        return res.end(pbsOutput);
    }

    // Handle PBSKids service
    if (service.toLowerCase() === 'pbskids') {
        const pbsKidsOutput = await handlePBSKids();
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        return res.end(pbsKidsOutput);
    }
   
    // If no matching service was found, send an error response
    res.writeHead(400, {
        'Content-Type': 'text/plain'
    });
    return res.end('Error: Unsupported service type provided');
});

//------ Proxy Stream Handler ------//

// Function to handle proxy streaming
async function handleProxyStream(req, res, pathname) {
    try {
        // Extract the service and channel ID from the pathname
        const streamPath = pathname.replace('/proxy/', '');
        const [service, channelId] = streamPath.split('/');
        
        let originalStreamUrl;
        
        // Determine the original stream URL based on the service
        switch(service.toLowerCase()) {
            case 'pluto':
                originalStreamUrl = `https://jmp2.uk/plu-${channelId}.m3u8`;
                break;
            case 'plex':
                originalStreamUrl = `https://jmp2.uk/plex-${channelId}.m3u8`;
                break;
            case 'samsung':
                originalStreamUrl = `https://jmp2.uk/sam-${channelId}.m3u8`;
                break;
            case 'roku':
                originalStreamUrl = `https://jmp2.uk/roku-${channelId}.m3u8`;
                break;
            case 'stirr':
                originalStreamUrl = `https://jmp2.uk/stirr-${channelId}.m3u8`;
                break;
            case 'tubi':
                originalStreamUrl = `https://jmp2.uk/tubi-${channelId}.m3u8`;
                break;
            case 'pbs':
                originalStreamUrl = `https://jmp2.uk/pbs-${channelId}.m3u8`;
                break;
            case 'pbskids':
                originalStreamUrl = `https://jmp2.uk/pbskids-${channelId}.m3u8`;
                break;
            case 'stream':
                // For direct stream URLs that were encoded in the proxy path
                originalStreamUrl = channelId;
                break;
            default:
                res.writeHead(400, { 'Content-Type': 'text/plain' });
                return res.end(`Error: Unsupported service type for proxy: ${service}`);
        }
        
        console.log(`Proxying stream: ${originalStreamUrl}`);
        
        // Set up headers for the proxy request
        const options = {
            headers: {
                'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
                'Referer': 'https://example.com',
            }
        };
        
        // Make the request to the original stream URL
        https.get(originalStreamUrl, options, (streamRes) => {
            // Copy all headers from the original response
            Object.keys(streamRes.headers).forEach(key => {
                res.setHeader(key, streamRes.headers[key]);
            });
            
            // Set the status code
            res.writeHead(streamRes.statusCode);
            
            // If it's an M3U8 playlist, we need to modify the URLs to point to our proxy
            if (streamRes.headers['content-type'] && 
                (streamRes.headers['content-type'].includes('application/vnd.apple.mpegurl') || 
                 streamRes.headers['content-type'].includes('application/x-mpegurl'))) {
                
                let body = '';
                streamRes.on('data', (chunk) => {
                    body += chunk.toString();
                });
                
                streamRes.on('end', () => {
                    // Replace URLs in the M3U8 playlist to point to our proxy
                    // This is a simplified approach and might need adjustments for specific services
                    const modifiedBody = body.replace(
                        /(https?:\/\/[^\s"']+)/g, 
                        (match) => {
                            // Don't proxy certain URLs like logos
                            if (match.includes('.jpg') || match.includes('.png') || match.includes('.svg')) {
                                return match;
                            }
                            // Create a proxy URL for the matched URL
                            return `http://${VPS_HOST}/proxy/stream/${encodeURIComponent(match)}`;
                        }
                    );
                    res.end(modifiedBody);
                });
            } else {
                // For non-M3U8 content, just pipe the response directly
                streamRes.pipe(res);
            }
        }).on('error', (e) => {
            console.error(`Proxy error: ${e.message}`);
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end(`Proxy Error: ${e.message}`);
        });
    } catch (error) {
        console.error(`Proxy error: ${error.message}`);
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end(`Proxy Error: ${error.message}`);
    }
}

// Handle direct stream proxying (for segments and other content)
server.on('request', (req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    
    if (pathname.startsWith('/proxy/stream/')) {
        try {
            // Extract the original URL from the path
            const originalUrl = decodeURIComponent(pathname.replace('/proxy/stream/', ''));
            
            console.log(`Proxying direct stream: ${originalUrl}`);
            
            // Set up headers for the proxy request
            const options = {
                headers: {
                    'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
                    'Referer': 'https://example.com',
                }
            };
            
            // Make the request to the original URL
            const protocol = originalUrl.startsWith('https') ? https : http;
            protocol.get(originalUrl, options, (streamRes) => {
                // Copy all headers from the original response
                Object.keys(streamRes.headers).forEach(key => {
                    res.setHeader(key, streamRes.headers[key]);
                });
                
                // Set the status code
                res.writeHead(streamRes.statusCode);
                
                // Pipe the response directly
                streamRes.pipe(res);
            }).on('error', (e) => {
                console.error(`Stream proxy error: ${e.message}`);
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end(`Stream Proxy Error: ${e.message}`);
            });
        } catch (error) {
            console.error(`Stream proxy error: ${error.message}`);
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end(`Stream Proxy Error: ${error.message}`);
        }
    }
});

//------ Service Functions ------//

// Function to handle the PlutoTV service
async function handlePlutoTV(region, sort) {
    const PLUTO_URL = 'https://i.mjh.nz/PlutoTV/.channels.json.gz';
    // Use our proxy URL instead of the direct stream URL
    const STREAM_URL_TEMPLATE = `http://${VPS_HOST}/proxy/pluto/${'{id}'}`;

    try {
        const data = await fetchGzippedJson(PLUTO_URL);
        let output = `#EXTM3U url-tvg="https://github.com/matthuisman/i.mjh.nz/raw/master/PlutoTV/${region}.xml.gz"\n`;
        let channels = {};

        if (region === 'all') {
            for (const regionKey in data.regions) {
                const regionData = data.regions[regionKey];
                const regionFullName = regionNameMap[regionKey] || regionKey.toUpperCase();
                for (const channelKey in regionData.channels) {
                    const channel = { ...regionData.channels[channelKey], region: regionFullName };
                    const uniqueChannelId = `${channelKey}-${regionKey}`;
                    channels[uniqueChannelId] = channel;
                }
            }
        } else {
            if (!data.regions[region]) {
                return `Error: Region '${region}' not found in Pluto data`;
            }
            channels = data.regions[region].channels || {};
        }

        const sortedChannelIds = Object.keys(channels).sort((a, b) => {
            const channelA = channels[a];
            const channelB = channels[b];
            return sort === 'chno' ? (channelA.chno - channelB.chno) : channelA.name.localeCompare(channelB.name);
        });

        sortedChannelIds.forEach(channelId => {
            const channel = channels[channelId];
            const { chno, name, group, logo, region: channelRegion } = channel;
            const groupTitle = region === 'all' ? `${channelRegion}` : group;

            output += `#EXTINF:-1 channel-id="${channelId}" tvg-id="${channelId}" tvg-chno="${chno}" tvg-name="${name}" tvg-logo="${logo}" group-title="${groupTitle}", ${name}\n`;
            output += STREAM_URL_TEMPLATE.replace('{id}', channelId.split('-')[0]) + '\n';
        });

        output = output.replace(/tvg-id="(.*?)-\w{2}"/g, 'tvg-id="$1"');
        return output;
    } catch (error) {
        console.error('Error fetching Pluto TV data:', error.message);
        return 'Error fetching Pluto data: ' + error.message;
    }
}

// Function to handle the Plex service
async function handlePlex(region, sort) {
    const PLEX_URL = 'https://i.mjh.nz/Plex/.channels.json.gz';
    const CHANNELS_JSON_URL = 'https://raw.githubusercontent.com/dtankdempse/free-iptv-channels/main/plex/channels.json';
    // Use our proxy URL instead of the direct stream URL
    const STREAM_URL_TEMPLATE = `http://${VPS_HOST}/proxy/plex/${'{id}'}`;

    sort = sort || 'name';
    let output = `#EXTM3U url-tvg="https://github.com/matthuisman/i.mjh.nz/raw/master/Plex/${region}.xml.gz"\n`;
    const regionNameMap = {
        us: "United States",
        mx: "Mexico",
        es: "Spain",
        ca: "Canada",
        au: "Australia",
        nz: "New Zealand"
    };

    try {
        // Fetch the Plex data
        console.log('Fetching new Plex data from URL:', PLEX_URL);
        const data = await fetchGzippedJson(PLEX_URL);

        console.log('Fetching new channels.json data from URL:', CHANNELS_JSON_URL);
        const plexChannels = await fetchJson(CHANNELS_JSON_URL);

        let channels = {};

        // Process channels based on region
        if (region === 'all') {
            for (const regionKey in data.regions) {
                const regionData = data.regions[regionKey];
                const regionFullName = regionNameMap[regionKey] || regionKey.toUpperCase();

                for (const channelKey in data.channels) {
                    const channel = data.channels[channelKey];
                    if (channel.regions.includes(regionKey)) {
                        const uniqueChannelId = `${channelKey}-${regionKey}`;
                        channels[uniqueChannelId] = {
                            ...channel,
                            region: regionFullName,
                            group: regionFullName,
                            originalId: channelKey
                        };
                    }
                }
            }
        } else {
            if (!data.regions[region]) {
                throw new Error(`Error: Region '${region}' not found in Plex data.`);
            }
            for (const channelKey in data.channels) {
                const channel = data.channels[channelKey];
                if (channel.regions.includes(region)) {
                    const matchingChannel = plexChannels.find(ch => ch.Title === channel.name);
                    const genre = matchingChannel && matchingChannel.Genre ? matchingChannel.Genre : 'Uncategorized';
                    channels[channelKey] = {
                        ...channel,
                        group: genre,
                        originalId: channelKey
                    };
                }
            }
        }

        // Sort channels based on the specified sorting criteria
        const sortedChannelIds = Object.keys(channels).sort((a, b) => {
            const channelA = channels[a];
            const channelB = channels[b];
            return sort === 'chno' ? (channelA.chno - channelB.chno) : channelA.name.localeCompare(channelB.name);
        });

        sortedChannelIds.forEach(channelId => {
            const channel = channels[channelId];
            const {
                chno,
                name,
                logo,
                group,
                originalId
            } = channel;

            output += `#EXTINF:-1 channel-id="${channelId}" tvg-id="${channelId}" tvg-chno="${chno || ''}" tvg-name="${name}" tvg-logo="${logo}" group-title="${group}", ${name}\n`;
            output += STREAM_URL_TEMPLATE.replace('{id}', originalId) + '\n';
        });

        output = output.replace(/tvg-id="(.*?)-\w{2}"/g, 'tvg-id="$1"');
        return output;

    } catch (error) {
        console.error('Error fetching Plex or channels data:', error.message);
        return `Error: ${error.message}`;
    }
}

// Function to handle the Samsung TV Plus service
async function handleSamsungTVPlus(region, sort) {
    const SAMSUNG_URL = 'https://i.mjh.nz/SamsungTVPlus/.channels.json.gz';
    // Use our proxy URL instead of the direct stream URL
    const STREAM_URL_TEMPLATE = `http://${VPS_HOST}/proxy/samsung/${'{id}'}`;

    try {
        const data = await fetchGzippedJson(SAMSUNG_URL);
        let output = `#EXTM3U url-tvg="https://github.com/matthuisman/i.mjh.nz/raw/master/SamsungTVPlus/${region}.xml.gz"\n`;
        let channels = {};

        if (region === 'all') {
            for (const regionKey in data.regions) {
                const regionData = data.regions[regionKey];
                const regionFullName = regionNameMap[regionKey] || regionKey.toUpperCase();
                for (const channelKey in regionData.channels) {
                    const channel = { ...regionData.channels[channelKey], region: regionFullName };
                    const uniqueChannelId = `${channelKey}-${regionKey}`;
                    channels[uniqueChannelId] = channel;
                }
            }
        } else {
            if (!data.regions[region]) {
                return `Error: Region '${region}' not found in Samsung TV Plus data`;
            }
            channels = data.regions[region].channels || {};
        }

        const sortedChannelIds = Object.keys(channels).sort((a, b) => {
            const channelA = channels[a];
            const channelB = channels[b];
            return sort === 'chno' ? (channelA.chno - channelB.chno) : channelA.name.localeCompare(channelB.name);
        });

        sortedChannelIds.forEach(channelId => {
            const channel = channels[channelId];
            const { chno, name, group, logo, region: channelRegion } = channel;
            const groupTitle = region === 'all' ? `${channelRegion}` : group;

            output += `#EXTINF:-1 channel-id="${channelId}" tvg-id="${channelId}" tvg-chno="${chno}" tvg-name="${name}" tvg-logo="${logo}" group-title="${groupTitle}", ${name}\n`;
            output += STREAM_URL_TEMPLATE.replace('{id}', channelId.split('-')[0]) + '\n';
        });

        output = output.replace(/tvg-id="(.*?)-\w{2}"/g, 'tvg-id="$1"');
        return output;
    } catch (error) {
        console.error('Error fetching Samsung TV Plus data:', error.message);
        return 'Error fetching Samsung TV Plus data: ' + error.message;
    }
}

// Function to handle the Roku service
async function handleRoku(sort) {
    const ROKU_URL = 'https://i.mjh.nz/Roku/.channels.json.gz';
    // Use our proxy URL instead of the direct stream URL
    const STREAM_URL_TEMPLATE = `http://${VPS_HOST}/proxy/roku/${'{id}'}`;

    try {
        const data = await fetchGzippedJson(ROKU_URL);
        let output = '#EXTM3U\n';
        let channels = data.channels || {};

        const sortedChannelIds = Object.keys(channels).sort((a, b) => {
            const channelA = channels[a];
            const channelB = channels[b];
            return sort === 'chno' ? (channelA.chno - channelB.chno) : channelA.name.localeCompare(channelB.name);
        });

        sortedChannelIds.forEach(channelId => {
            const channel = channels[channelId];
            const { chno, name, group, logo } = channel;

            output += `#EXTINF:-1 channel-id="${channelId}" tvg-id="${channelId}" tvg-chno="${chno || ''}" tvg-name="${name}" tvg-logo="${logo}" group-title="${group || 'Roku'}", ${name}\n`;
            output += STREAM_URL_TEMPLATE.replace('{id}', channelId) + '\n';
        });

        return output;
    } catch (error) {
        console.error('Error fetching Roku data:', error.message);
        return 'Error fetching Roku data: ' + error.message;
    }
}

// Function to handle the Stirr service
async function handleStirr(sort) {
    const STIRR_URL = 'https://i.mjh.nz/Stirr/.channels.json.gz';
    // Use our proxy URL instead of the direct stream URL
    const STREAM_URL_TEMPLATE = `http://${VPS_HOST}/proxy/stirr/${'{id}'}`;

    try {
        const data = await fetchGzippedJson(STIRR_URL);
        let output = '#EXTM3U\n';
        let channels = data.channels || {};

        const sortedChannelIds = Object.keys(channels).sort((a, b) => {
            const channelA = channels[a];
            const channelB = channels[b];
            return sort === 'chno' ? (channelA.chno - channelB.chno) : channelA.name.localeCompare(channelB.name);
        });

        sortedChannelIds.forEach(channelId => {
            const channel = channels[channelId];
            const { chno, name, group, logo } = channel;

            output += `#EXTINF:-1 channel-id="${channelId}" tvg-id="${channelId}" tvg-chno="${chno || ''}" tvg-name="${name}" tvg-logo="${logo}" group-title="${group || 'Stirr'}", ${name}\n`;
            output += STREAM_URL_TEMPLATE.replace('{id}', channelId) + '\n';
        });

        return output;
    } catch (error) {
        console.error('Error fetching Stirr data:', error.message);
        return 'Error fetching Stirr data: ' + error.message;
    }
}

// Function to handle the Tubi service
async function handleTubi() {
    const TUBI_URL = 'https://i.mjh.nz/Tubi/.channels.json.gz';
    // Use our proxy URL instead of the direct stream URL
    const STREAM_URL_TEMPLATE = `http://${VPS_HOST}/proxy/tubi/${'{id}'}`;

    try {
        const data = await fetchGzippedJson(TUBI_URL);
        let output = '#EXTM3U\n';
        let channels = data.channels || {};

        const sortedChannelIds = Object.keys(channels).sort((a, b) => {
            return channels[a].name.localeCompare(channels[b].name);
        });

        sortedChannelIds.forEach(channelId => {
            const channel = channels[channelId];
            const { name, group, logo } = channel;

            output += `#EXTINF:-1 channel-id="${channelId}" tvg-id="${channelId}" tvg-name="${name}" tvg-logo="${logo}" group-title="${group || 'Tubi'}", ${name}\n`;
            output += STREAM_URL_TEMPLATE.replace('{id}', channelId) + '\n';
        });

        return output;
    } catch (error) {
        console.error('Error fetching Tubi data:', error.message);
        return 'Error fetching Tubi data: ' + error.message;
    }
}

// Function to handle the PBS service
async function handlePBS() {
    const PBS_URL = 'https://i.mjh.nz/PBS/.channels.json.gz';
    // Use our proxy URL instead of the direct stream URL
    const STREAM_URL_TEMPLATE = `http://${VPS_HOST}/proxy/pbs/${'{id}'}`;

    try {
        const data = await fetchGzippedJson(PBS_URL);
        let output = '#EXTM3U\n';
        let channels = data.channels || {};

        const sortedChannelIds = Object.keys(channels).sort((a, b) => {
            return channels[a].name.localeCompare(channels[b].name);
        });

        sortedChannelIds.forEach(channelId => {
            const channel = channels[channelId];
            const { name, group, logo } = channel;

            output += `#EXTINF:-1 channel-id="${channelId}" tvg-id="${channelId}" tvg-name="${name}" tvg-logo="${logo}" group-title="${group || 'PBS'}", ${name}\n`;
            output += STREAM_URL_TEMPLATE.replace('{id}', channelId) + '\n';
        });

        return output;
    } catch (error) {
        console.error('Error fetching PBS data:', error.message);
        return 'Error fetching PBS data: ' + error.message;
    }
}

// Function to handle the PBSKids service
async function handlePBSKids() {
    const PBSKIDS_URL = 'https://i.mjh.nz/PBSKids/.channels.json.gz';
    // Use our proxy URL instead of the direct stream URL
    const STREAM_URL_TEMPLATE = `http://${VPS_HOST}/proxy/pbskids/${'{id}'}`;

    try {
        const data = await fetchGzippedJson(PBSKIDS_URL);
        let output = '#EXTM3U\n';
        let channels = data.channels || {};

        const sortedChannelIds = Object.keys(channels).sort((a, b) => {
            return channels[a].name.localeCompare(channels[b].name);
        });

        sortedChannelIds.forEach(channelId => {
            const channel = channels[channelId];
            const { name, group, logo } = channel;

            output += `#EXTINF:-1 channel-id="${channelId}" tvg-id="${channelId}" tvg-name="${name}" tvg-logo="${logo}" group-title="${group || 'PBS Kids'}", ${name}\n`;
            output += STREAM_URL_TEMPLATE.replace('{id}', channelId) + '\n';
        });

        return output;
    } catch (error) {
        console.error('Error fetching PBS Kids data:', error.message);
        return 'Error fetching PBS Kids data: ' + error.message;
    }
}

// Function to handle the home page
function handleHomePage(res) {
    const html = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>IPTV Proxy Server</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
            h1 { color: #333; }
            h2 { color: #555; margin-top: 30px; }
            code { background-color: #f5f5f5; padding: 2px 5px; border-radius: 3px; }
            pre { background-color: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
            .warning { color: #a00; }
        </style>
    </head>
    <body>
        <h1>IPTV Proxy Server</h1>
        <p>This server provides M3U8 playlists for various free IPTV services with all streams proxied through this server.</p>
        
        <h2>Usage</h2>
        <p>Access the M3U8 playlist using the following URL format:</p>
        <pre>http://${VPS_HOST}/m3u8?service=[SERVICE]&region=[REGION]&sort=[SORT]</pre>
        
        <h2>Available Services</h2>
        <ul>
            <li><code>pluto</code> - Pluto TV</li>
            <li><code>plex</code> - Plex</li>
            <li><code>samsung</code> - Samsung TV Plus</li>
            <li><code>roku</code> - Roku</li>
            <li><code>stirr</code> - Stirr</li>
            <li><code>tubi</code> - Tubi</li>
            <li><code>pbs</code> - PBS</li>
            <li><code>pbskids</code> - PBS Kids</li>
        </ul>
        
        <h2>Available Regions</h2>
        <p>For region-specific services (Pluto TV, Plex, Samsung TV Plus):</p>
        <ul>
            <li><code>us</code> - United States</li>
            <li><code>ca</code> - Canada</li>
            <li><code>uk</code> or <code>gb</code> - United Kingdom</li>
            <li><code>de</code> - Germany</li>
            <li><code>es</code> - Spain</li>
            <li><code>fr</code> - France</li>
            <li><code>it</code> - Italy</li>
            <li><code>all</code> - All available regions</li>
        </ul>
        
        <h2>Sorting Options</h2>
        <ul>
            <li><code>name</code> - Sort by channel name (default)</li>
            <li><code>chno</code> - Sort by channel number</li>
        </ul>
        
        <h2>Examples</h2>
        <ul>
            <li>Pluto TV (US): <a href="/m3u8?service=pluto&region=us&sort=name">http://${VPS_HOST}/m3u8?service=pluto&region=us&sort=name</a></li>
            <li>Plex (All regions): <a href="/m3u8?service=plex&region=all">http://${VPS_HOST}/m3u8?service=plex&region=all</a></li>
            <li>Samsung TV Plus (UK): <a href="/m3u8?service=samsung&region=gb">http://${VPS_HOST}/m3u8?service=samsung&region=gb</a></li>
        </ul>
        
        <h2>Important Notes</h2>
        <p class="warning">This proxy server will use your VPS bandwidth for all streams. Be aware of potential bandwidth costs and limitations.</p>
        <p class="warning">The legality of streaming these channels may vary by region. Use at your own risk.</p>
    </body>
    </html>
    `;

    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(html);
}

// Fetch JSON data from the provided URL
function fetchJson(url) {
    return new Promise((resolve, reject) => {
        https.get(url, (res) => {
            let data = '';

            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (error) {
                    reject(error);
                }
            });
        }).on('error', (error) => {
            reject(error);
        });
    });
}

// function to fetch and decompresses gzipped JSON files
async function fetchGzippedJson(url, maxRedirects = 5) {
    return new Promise((resolve, reject) => {
        const makeRequest = (currentUrl, redirectsRemaining) => {
            https.get(currentUrl, (response) => {
                if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
                    if (redirectsRemaining <= 0) {
                        reject(new Error('Too many redirects'));
                        return;
                    }
                    const redirectUrl = new URL(response.headers.location, currentUrl).href;
                    makeRequest(redirectUrl, redirectsRemaining - 1);
                    return;
                }

                if (response.statusCode !== 200) {
                    reject(new Error(`Request failed. Status code: ${response.statusCode}`));
                    return;
                }

                const gunzip = zlib.createGunzip();
                const chunks = [];
                response.pipe(gunzip);

                gunzip.on('data', (chunk) => chunks.push(chunk));
                gunzip.on('end', () => {
                    try {
                        resolve(JSON.parse(Buffer.concat(chunks).toString('utf-8')));
                    } catch (error) {
                        reject(new Error('Failed to parse JSON: ' + error.message));
                    }
                });
                gunzip.on('error', (error) => reject(error));
            }).on('error', (error) => reject(error));
        };

        makeRequest(url, maxRedirects);
    });
}

server.listen(port, hostname, () => {
    console.log(`Proxy server running at http://${hostname}:${port}/`);
    console.log(`Set VPS_HOST environment variable to your VPS hostname or IP (currently: ${VPS_HOST})`);
});