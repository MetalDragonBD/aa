# IPTV Proxy Server Setup

This guide explains how to set up the IPTV proxy server that will stream content through your VPS bandwidth.

## Overview

The proxy server implementation allows you to route all streaming traffic through your VPS instead of directly connecting to the content providers. This means:

- All streaming data will pass through your VPS
- Your VPS bandwidth will be used for all streams
- The VPS acts as a middleman between content providers and end users

## Important Considerations

Before deploying this proxy server, please consider:

1. **Bandwidth Usage**: Streaming video consumes significant bandwidth. Your VPS provider may charge for bandwidth overages.
2. **Performance**: Your VPS's network capacity will limit the number of concurrent streams and quality.
3. **Legal Implications**: Proxying copyrighted content may have legal implications in your jurisdiction.
4. **Latency**: Adding a proxy layer increases latency and may affect streaming quality.

## Setup Instructions

### 1. Configure the VPS Host

Edit the `docker-compose.proxy.yml` file and replace `your-vps-ip-or-domain:8765` with your actual VPS IP address or domain name and the port you want to expose (default is 8765).

```yaml
environment:
  - VPS_HOST=your-vps-ip-or-domain:8765  # Replace with your actual VPS IP or domain
```

### 2. Deploy with Docker Compose

```bash
# Build and start the proxy server
docker-compose -f docker-compose.proxy.yml up -d
```

### 3. Access the Proxy Server

The proxy server will be available at:

```
http://your-vps-ip-or-domain:8765/m3u8?service=pluto&region=us&sort=name
```

Replace the parameters as needed:
- `service`: pluto, plex, samsung, roku, stirr, tubi, pbs, pbskids
- `region`: us, ca, uk, de, es, fr, it, etc.
- `sort`: name, channel

### 4. Stream Through the Proxy

All streams in the M3U8 playlist will be routed through your VPS using the proxy endpoint:

```
http://your-vps-ip-or-domain:8765/proxy?url=encoded-stream-url
```

## Monitoring

To monitor bandwidth usage:

```bash
# View logs
docker-compose -f docker-compose.proxy.yml logs -f

# Check container stats (CPU, memory, network)
docker stats
```

## Troubleshooting

If you encounter issues:

1. Check that your VPS firewall allows traffic on port 8765
2. Ensure your VPS has sufficient bandwidth capacity
3. Verify that the `VPS_HOST` environment variable is correctly set
4. Check the container logs for any error messages

## Stopping the Proxy Server

```bash
docker-compose -f docker-compose.proxy.yml down
```